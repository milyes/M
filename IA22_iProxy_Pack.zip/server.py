from flask import Flask, request, jsonify
import json

app = Flask(__name__)

with open("medical_db.json", "r", encoding="utf-8") as f:
    medicalDB = json.load(f)

def analyze_text(text):
    text = text.lower()
    results = []
    for entry in medicalDB:
        if any(k in text for k in entry["keywords"]):
            results.append(entry)
    return results if results else [{"symptom":"Non identifié","causes":"-","advice":"Décrire plus précisément"}]

@app.route('/analyze', methods=['POST'])
def analyze():
    data = request.get_json()
    text = data.get("input", "")
    return jsonify({"result": analyze_text(text)})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)