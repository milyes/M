#!/bin/bash
echo "[IA22_iProxy] Démarrage..."
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python server.py &
echo "🌍 Backend lancé sur http://127.0.0.1:5000"
echo "🔗 Lancer un tunnel ngrok/cloudflared si besoin..."
