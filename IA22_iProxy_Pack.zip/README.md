# IA22_iProxy – Analyse Médicale IA

Projet de démonstration médicale IA avec double mode :
- **Online (backend Flask)** exposé via `/analyze`
- **Offline (fallback local)** via base embarquée JSON

## Installation

```bash
git clone <repo>
cd IA22_iProxy_Pack
chmod +x run.sh
./run.sh
```

Accéder via `http://127.0.0.1:5000/index.html`

## Tunnel

Exemple avec ngrok :
```bash
ngrok http 5000
```

## Auteur
**Zoubirou Mohammed Ilyes**  
ORCID: https://orcid.org/0009-0007-7571-3178