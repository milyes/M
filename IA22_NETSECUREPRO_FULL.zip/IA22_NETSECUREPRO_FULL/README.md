# IA22_LOGIC Médicale — NetSecurePro IA (Online + Offline hybrid)
Auteur: Zoubirou Mohammed Ilyes
ORCID: 0009-0007-7571-3178

Contenu:
- frontend/index.html -> page web (offline heuristics + online via /analyse)
- backend/app.py -> Flask backend qui fournit /analyse
- backend/requirements.txt -> dépendances Python
- run.sh -> script pour lancer le backend (Linux/Termux)
- Dockerfile -> optionnel pour containerisation
- LICENSE -> MIT

Instructions rapides (Linux / Termux / VPS):
1. Installer Python 3.8+ et pip.
2. Aller dans le dossier backend: `cd backend`
3. Installer dépendances: `pip install -r requirements.txt`
4. Lancer le serveur: `python app.py` (écoute sur 0.0.0.0:5000)
5. Ouvrir `frontend/index.html` dans un navigateur ou packager en WebView/APK.
 
Notes:
- Le backend effectue d'abord une analyse heuristique locale. Si la variable d'environnement OPENAI_API_KEY est définie, le backend tentera d'appeler l'API OpenAI (optionnel).
- Pour production, utilisez HTTPS (traefik/nginx) ou Cloudflare Tunnel. Protégez l'endpoint /analyse par clé API si exposé publiquement.
