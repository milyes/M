#!/bin/bash
# Script simple pour lancer le backend Flask
cd backend
python3 app.py
