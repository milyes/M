
from flask import Flask, request, jsonify
from flask_cors import CORS
import os
import re
import openai

app = Flask(__name__)
CORS(app)

# Heuristic rules (same logic as frontend)
RULES = [
    (['fièvre','température','38','39','hyperthermie'],'modéré','Surveillez la température, hydratez-vous et consultez si >38.5°C ou si signes de détérioration.'),
    (['toux','tousse','toux sèche','expectoration'],'léger','Toux possible infection des voies respiratoires. Repos, hydratation; consulter si durent >10 jours ou s\\'aggravent.'),
    (['douleur thoracique','oppression thoracique','douleur poitrine'],'élevé','Symptôme potentiellement grave. Consulter d\\'urgence (SAMU/112).'),
    (['essoufflement','dyspnée','difficulté à respirer'],'élevé','Symptôme grave — consulter d\\'urgence immédiatement.'),
    (['fatigue','fatigue chronique','épuisement'],'léger','Peut être lié à de nombreux facteurs: sommeil, nutrition, stress. Consulter si persistant.'),
    (['nausée','vomissement'],'modéré','Hydratation, repos; consulter si vomissements sévères ou persistants.')
]

LEVELS = {'léger':1,'modéré':2,'élevé':3}

def sanitize(text):
    if not text: return ''
    text = str(text).lower()
    text = re.sub(r'<[^>]+>','',text)
    return text

def heuristic_analysis(text):
    raw = sanitize(text)
    found = []
    for keywords, severity, advice in RULES:
        for k in keywords:
            if k in raw:
                found.append({'keyword':k,'severity':severity,'advice':advice})
                break
    max_level = 0
    for f in found:
        max_level = max(max_level, LEVELS.get(f['severity'],0))
    severity_map = {1:'léger',2:'modéré',3:'élevé'}
    verdict = severity_map.get(max_level,'indéterminé')
    report_lines = []
    report_lines.append('🔬 Rapport d\\'analyse (backend) - IA22_LOGIC')
    report_lines.append('Entrée: {}'.format(raw))
    if not found:
        report_lines.append('Aucun mot-clé critique détecté. Recommandation: surveiller les symptômes et consulter si apparition de signes graves.')
    else:
        report_lines.append('Symptômes / indices détectés:')
        for f in found:
            report_lines.append(" - {keyword} (sévérité: {severity}) -> {advice}".format(**f))
    report_lines.append('\\nVerdict global (heuristique): {}'.format(verdict))
    report_lines.append('\\n⚠️ Ce diagnostic est indicatif. Consultez un professionnel de santé pour un diagnostic formel.')
    return {'report':'\\n'.join(report_lines),'found':found,'verdict':verdict}

def call_openai(texte):
    # Optional: call OpenAI if API key present. Return dict or None on error.
    key = os.getenv('OPENAI_API_KEY') or os.getenv('OPENAI_API_KEY'.lower())
    if not key:
        return None
    try:
        openai.api_key = key
        prompt = f"Vous êtes un assistant médical prudent. Résumez et fournissez des recommandations courtes pour le texte suivant:\\n\\n{texte}\\n\\nDonnez un verdict bref et conseils."
        response = openai.ChatCompletion.create(
            model="gpt-4o-mini", # user can change
            messages=[{"role":"system","content":"Assistant médical. Rédigez en français."},
                      {"role":"user","content":prompt}],
            max_tokens=500,
            temperature=0.2
        )
        return {'openai_raw': response.choices[0].message.content.strip()}
    except Exception as e:
        return {'error':str(e)}

@app.route('/analyse', methods=['POST'])
def analyse():
    data = request.get_json() or {}
    texte = data.get('texte') or data.get('text') or ''
    if not str(texte).strip():
        return jsonify({'error':'Entrée vide'}), 400
    # First try OpenAI online if configured
    oa = call_openai(texte)
    if oa and 'error' not in oa:
        return jsonify({'mode':'online','source':'openai','rapport': oa}), 200
    # Fallback to heuristic
    h = heuristic_analysis(texte)
    return jsonify({'mode':'offline-fallback','source':'heuristic','rapport':h}), 200

if __name__ == '__main__':
    port = int(os.environ.get('PORT', '5000'))
    app.run(host='0.0.0.0', port=port, debug=True)
