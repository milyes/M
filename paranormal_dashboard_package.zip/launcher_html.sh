#!/bin/bash
# launcher_html.sh - lance le dashboard paranormal dans le navigateur
HTML_FILE="paranormal_dashboard.html"

if [ ! -f "$HTML_FILE" ]; then
    echo "Erreur: le fichier HTML '$HTML_FILE' n'existe pas."
    exit 1
fi

echo "Ouverture du dashboard: $HTML_FILE"

if command -v xdg-open &> /dev/null; then
    xdg-open "$HTML_FILE"
elif command -v open &> /dev/null; then
    open "$HTML_FILE"
elif command -v termux-open &> /dev/null; then
    termux-open "$HTML_FILE"
else
    echo "Impossible de détecter le navigateur par défaut. Ouvrez $HTML_FILE manuellement."
    exit 1
fi
